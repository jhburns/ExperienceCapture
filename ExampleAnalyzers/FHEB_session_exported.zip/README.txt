README - About file layout

- FHEB.onlyCaptures.json: Only data collected from the GetCapture() method.
- FHEB.sessionInfo.json: Extra info about the session, from the client.
- FHEB.database.json: Extra info about the session, from the server.
- CSVs/ : all of the GetCapture() data, separated by scene.
- FHEB.raw.json: A straight dump of the session information. Only really useful in the case export didn't work correctly.